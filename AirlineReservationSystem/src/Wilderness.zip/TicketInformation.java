package Wilderness;

public class TicketInformation {
	String Date = null;
	String GoDate = null;
	String BackDate = null;
	String startplace = null;
	String arrplace = null;
	String Food = null;
	String Baggage = null;
	String SeatUp = null;
	
}
